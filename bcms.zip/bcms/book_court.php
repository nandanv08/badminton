<?php 
require_once('config.php');
require_once('inc/header.php'); // Or wherever you keep layout

if(!isset($_SESSION['userdata'])){
    header("Location: login.php");
    exit;
}
?>
<div class="container py-4">
    <h3>Book a Court</h3>
    <form action="save_booking.php" method="POST">
        <div class="form-group">
            <label for="court">Select Court</label>
            <select name="court_id" class="form-control" required>
                <?php
                $courts = $conn->query("SELECT * FROM court_list WHERE delete_flag = 0");
                while($row = $courts->fetch_assoc()):
                ?>
                    <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="datetime_start">Start Time</label>
            <input type="datetime-local" name="datetime_start" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="datetime_end">End Time</label>
            <input type="datetime-local" name="datetime_end" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Book Now</button>
    </form>
</div>
